package com.etjava.mapper;

import com.etjava.model.User;

import java.util.List;

public interface UserMapper {
    public List<User> findUser();
}
