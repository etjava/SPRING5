package com.etjava.mapper.impl;

import com.etjava.mapper.UserMapper;
import com.etjava.model.User;
import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import java.util.List;

public class UserMapperImpl2 extends SqlSessionDaoSupport implements UserMapper {
    @Override
    public List<User> findUser() {
        // SqlSessionDaoSupport提供的可以直接获取sqlSession
        SqlSession sqlSession = getSqlSession();
        UserMapper u = sqlSession.getMapper(UserMapper.class);
        return u.findUser();
    }
}
