package com.etjava.test;

import com.etjava.mapper.UserMapper;
import com.etjava.mapper.impl.UserMapperImpl;
import com.etjava.mapper.impl.UserMapperImpl2;
import com.etjava.model.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class TestMyBaits {

    @Test
    public void test1() throws IOException {
        // 读取mybatis配置文件
        InputStream is = Resources.getResourceAsStream("mybatis-config.xml");
        // 创建session工厂
        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(is);
        // 获取sqlSession 自动提交 传入true
        SqlSession sqlSession = sessionFactory.openSession(true);
        // 获取接口映射
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        List<User> list = mapper.findUser();
        for (User u: list) {
            System.out.println(u);
        }
    }

    @Test
    public void test2(){
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        UserMapperImpl userMapper = context.getBean("userMapper", UserMapperImpl.class);
        List<User> list = userMapper.findUser();
        for (User user : list) {
            System.out.println(user);
        }
    }

    @Test
    public void test3(){
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        UserMapperImpl2 userMapper = context.getBean("userMapper2", UserMapperImpl2.class);
        List<User> list = userMapper.findUser();
        for (User user : list) {
            System.out.println(user);
        }
    }
}
