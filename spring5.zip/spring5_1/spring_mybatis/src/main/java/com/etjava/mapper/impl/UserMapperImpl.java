package com.etjava.mapper.impl;

import com.etjava.mapper.UserMapper;
import com.etjava.model.User;
import org.mybatis.spring.SqlSessionTemplate;

import java.util.List;

public class UserMapperImpl implements UserMapper {

    // 我们之前所有的操作都是使用sqlSession 整合Sprign后都是使用SqlSessionTemplate
    private SqlSessionTemplate sqlSession;


    public void setSqlSession(SqlSessionTemplate sqlSession) {
        this.sqlSession = sqlSession;
    }

    @Override
    public List<User> findUser() {
        UserMapper u = sqlSession.getMapper(UserMapper.class);
        return u.findUser();
    }
}
