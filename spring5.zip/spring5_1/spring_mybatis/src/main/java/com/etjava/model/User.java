package com.etjava.model;

import lombok.Data;

@Data
public class User {
    private Integer id;
    private String stuName;
    private Integer age;
}
