package com.etjava.model;

import java.util.*;

public class Student {
    private String stuName;
    private Address address;
    private String[] data;
    private List<String> list;
    private Map<String,Object> map;
    private Set<String> set;
    private String nullVal;
    private Properties prop;

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String[] getData() {
        return data;
    }

    public void setData(String[] data) {
        this.data = data;
    }

    public List<String> getList() {
        return list;
    }

    public void setList(List<String> list) {
        this.list = list;
    }

    public Map<String, Object> getMap() {
        return map;
    }

    public void setMap(Map<String, Object> map) {
        this.map = map;
    }

    public Set<String> getSet() {
        return set;
    }

    public void setSet(Set<String> set) {
        this.set = set;
    }

    public String getNullVal() {
        return nullVal;
    }

    public void setNullVal(String nullVal) {
        this.nullVal = nullVal;
    }

    public Properties getProp() {
        return prop;
    }

    public void setProp(Properties prop) {
        this.prop = prop;
    }

    @Override
    public String toString() {
        return "Student{" +
                "stuName='" + stuName + '\'' +
                ", address=" + address +
                ", data=" + Arrays.toString(data) +
                ", list=" + list +
                ", map=" + map +
                ", set=" + set +
                ", nullVal='" + nullVal + '\'' +
                ", prop=" + prop +
                '}';
    }
}
