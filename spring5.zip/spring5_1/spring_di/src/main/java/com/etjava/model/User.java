package com.etjava.model;

public class User {
    private String userName;

    public User() {
        System.out.println("无参构造方法");
    }

    public User(String userName) {
        System.out.println("有参构造方法");
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
