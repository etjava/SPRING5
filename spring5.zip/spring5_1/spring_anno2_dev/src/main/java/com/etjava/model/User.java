package com.etjava.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

// Component 定义为组件的注解
// 等价于 <bean id="user" class="com.etjava.model.User"/>
@Component
@Scope("singleton")// prototype 原型模式  singeton单例模式
public class User {
    @Value("Tom")// 给属性注入值,优先级低于直接赋值 但它会覆盖掉之前的值
    public String name = "ET";
}
