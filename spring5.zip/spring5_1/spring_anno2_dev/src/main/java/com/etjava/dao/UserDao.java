package com.etjava.dao;

import org.springframework.stereotype.Repository;

@Repository
public class UserDao {
}
