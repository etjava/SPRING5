package com.etjava;


public class Test2 {
    public static void main(String[] args) {
        // 真实角色
        Host host = new Host();
        // 代理角色 - 需要动态创建
        ProxyInvocationHandler pih = new ProxyInvocationHandler();
        // 通过调用程序处理对象(InvocationHandler)来处理我们要调用的接口对象
        pih.setRent(host);
        // 获取代理对象
        Rent proxy = (Rent) pih.getProxy();
        // 执行代理方法
        proxy.rent();
    }
}
