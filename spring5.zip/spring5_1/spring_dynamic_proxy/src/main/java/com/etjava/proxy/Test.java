package com.etjava.proxy;


import com.etjava.Host;
import com.etjava.Rent;

public class Test {
    public static void main(String[] args) {
        // 真实角色
        UserServiceImpl userService = new UserServiceImpl();
        // 代理角色
        ProxyInvocationHandler pih = new ProxyInvocationHandler();
        // 设置要代理的对象
        pih.setTarget(userService);
        // 获取代理对象 - 返回的代理对象是接口或抽象类 不能是普通类
        UserService proxy = (UserService) pih.getProxy();
        proxy.query();

        // 测试代理Host 租房业务
        Host host = new Host();
        pih.setTarget(host);
        Rent proxy1 = (Rent)pih.getProxy();
        proxy1.rent();

    }
}
