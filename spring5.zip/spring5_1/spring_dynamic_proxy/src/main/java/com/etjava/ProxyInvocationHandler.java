package com.etjava;


import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

// 自动生成代理的类
public class ProxyInvocationHandler implements InvocationHandler {

    private Rent rent;

    public void setRent(Rent rent) {
        this.rent = rent;
    }

    // 生成代理的类
    public Object getProxy(){
        /*
        newProxyInstance 生成代理对象
        方法参数解释
        ClassLoader loader,   当前类的类加载器
        Class<?>[] interfaces, 被代理的抽象角色 - 通常是接口(被代理的接口)
        InvocationHandler h 代理处理程序本身 即 this
         */
        return Proxy.newProxyInstance(this.getClass().getClassLoader(),rent.getClass().getInterfaces(),this );
    }

    // 处理代理实例 并返回处理结果
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        /*
            invoke(rent,args);
            参数 1 需要执行哪个方法
            参数2 执行的方法需要的参数

            动态代理的机制就是使用反射机制实现
         */
        return method.invoke(rent,args);
    }


}
