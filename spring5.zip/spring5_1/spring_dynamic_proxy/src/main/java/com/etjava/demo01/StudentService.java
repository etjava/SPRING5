package com.etjava.demo01;

public interface StudentService {
    public void add();
    public void delete();
    public void update();
    public void query();
}
