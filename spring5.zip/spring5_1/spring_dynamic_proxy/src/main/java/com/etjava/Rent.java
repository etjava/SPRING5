package com.etjava;

// 租房
public interface Rent {

    public void rent();
}
