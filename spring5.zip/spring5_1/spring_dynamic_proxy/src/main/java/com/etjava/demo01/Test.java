package com.etjava.demo01;

public class Test {
    public static void main(String[] args) {
        //
        MyProxyInvocationHandlet pih = new MyProxyInvocationHandlet();
        // 创建需要代理的对象
        StudentService studentService = new StudentServiceImpl();
        // 设置被代理的对象
        pih.setTarget(studentService);
        // 获取代理对象
        StudentService proxy = (StudentService)pih.getProxy();
        proxy.add();
        proxy.delete();
        proxy.update();
        proxy.query();
    }
}
