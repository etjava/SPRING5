package com.etjava.demo01;

public class StudentServiceImpl implements StudentService{
    @Override
    public void add() {
        System.out.println("添加学生的方法");
    }

    @Override
    public void delete() {
        System.out.println("删除学生的方法");
    }

    @Override
    public void update() {
        System.out.println("修改学生的方法");
    }

    @Override
    public void query() {
        System.out.println("查询学生的方法");
    }
}
