package com.etjava.model;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        User u1 = (User)context.getBean("u1");
        User u2 = (User)context.getBean("u2");

        System.out.println(u1==u2);
    }
}
