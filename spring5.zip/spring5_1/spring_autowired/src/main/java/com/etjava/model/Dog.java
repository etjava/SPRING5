package com.etjava.model;

public class Dog {
    public void eat(){
        System.out.println("狗吃肉~");
    }
}
