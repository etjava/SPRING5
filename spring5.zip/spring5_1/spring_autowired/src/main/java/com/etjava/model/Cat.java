package com.etjava.model;

public class Cat {
    public void eat(){
        System.out.println("猫吃鱼~");
    }
}
