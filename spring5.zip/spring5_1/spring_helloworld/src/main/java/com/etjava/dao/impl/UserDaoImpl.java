package com.etjava.dao.impl;

import com.etjava.dao.UserDao;

public class UserDaoImpl implements UserDao {
    @Override
    public void defaultMethod() {
        System.out.println("dao层处理用户数据的默认方法");
    }
}
