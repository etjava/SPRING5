package com.etjava.test;

import com.etjava.service.UserService;
import com.etjava.service.UserServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test2 {
    public static void main(String[] args) {
        // 创建Spring上下文对象
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        // 获取bean  注意 这里获取的bean必须是applicationContext中配置好的
        UserService userServiceImpl = (UserServiceImpl) context.getBean("userServiceImpl");
        // 调用Service中的方法
        userServiceImpl.test();
    }
}
