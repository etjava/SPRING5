package com.etjava.test;

import com.etjava.model.User;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloWorld {
    public static void main(String[] args) {
        // 创建ApplicationContext对象 用来获取Spring的上下文对象
        ApplicationContext context =
                new ClassPathXmlApplicationContext("applicationContext.xml");
        // 在Spring的上下文对象中获取指定的bean
        User user = (User)context.getBean("user");
        System.out.println(user);
    }
}
