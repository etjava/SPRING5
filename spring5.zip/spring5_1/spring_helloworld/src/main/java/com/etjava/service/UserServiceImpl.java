package com.etjava.service;

import com.etjava.dao.UserDao;

public class UserServiceImpl implements UserService{

    private UserDao userDao;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }
    @Override
    public void test() {
        userDao.defaultMethod();
    }
}
