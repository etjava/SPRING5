package com.etjava.service;

public interface UserService {
    void test();
}
