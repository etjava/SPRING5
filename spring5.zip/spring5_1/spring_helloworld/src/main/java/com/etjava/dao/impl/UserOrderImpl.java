package com.etjava.dao.impl;

import com.etjava.dao.UserDao;

public class UserOrderImpl implements UserDao {
    @Override
    public void defaultMethod() {
        System.out.println("dao层处理用户订单数据的默认方法");
    }
}
