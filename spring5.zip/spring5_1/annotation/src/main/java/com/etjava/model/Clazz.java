package com.etjava.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.lang.Nullable;

import javax.annotation.Resource;

public class Clazz {

    private String className;
    // 对应的是spring配置文件中配置好的bean
    // 如果我们设置了Autowired属性required值为false  表示该属性可以为null
//    @Autowired(required = false)
//    @Qualifier(value = "student2")// 表示去IOC中查找对应名字的bean
    @Resource(name = "stu2")// 指定IOC配置的bean
    private Student stu;
    @Resource
    private Teacher teacher;

    // 添加了Nullable 注解 表示该参数可以为null
    public Clazz(@Nullable  String className) {
        this.className = className;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public Student getStu() {
        return stu;
    }

    public void setStu(Student stu) {
        this.stu = stu;
    }

    public Teacher getTeacher() {
        return teacher;
    }
    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }
}
