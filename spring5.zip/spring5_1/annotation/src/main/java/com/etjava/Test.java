package com.etjava;

import com.etjava.model.Clazz;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Clazz clazz = context.getBean("clazz", Clazz.class);
        clazz.getTeacher().teach();
        clazz.getStu().study();

    }
}
