package com.etjava.model;

public class Teacher {
    public void teach(){
        System.out.println("老师教学的方法");
    }
}
