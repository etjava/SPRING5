package com.etjava.model;

public class Student {
   public void study(){
       System.out.println("学生学习的方法");
   }
}
