package com.etjava.model;

import org.springframework.beans.factory.annotation.Value;
// 这里不需要在使用@Component注解来注入到Spring容器中
// 因为使用@Configuration进行配置bean时 通过@Bean方式作为属性去引用了
public class User {
    private String name;

    public String getName() {
        return name;
    }

    @Value("Tom")// 给name赋值 @Value还可以写在属性上
    public void setName(String name) {
        this.name = name;
    }
}
