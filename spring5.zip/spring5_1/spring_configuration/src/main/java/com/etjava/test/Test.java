package com.etjava.test;

import com.etjava.config.AppConfig;
import com.etjava.model.User;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
    public static void main(String[] args) {
        // 如果使用了配置类的方式 替代spring的配置文件 那么我们只能通过AnnotationConfig上下文获取spring容器
        // 通过配置类的class对象加载到配置类
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        // 获取的bean 是AppConfig中对应的方法名
        User user = context.getBean("user", User.class);
        System.out.println(user.getName());
    }
}
