package com.etjava.config;

import com.etjava.model.User;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;


/*
    @Configuration 代表Spring的配置类 与applicationContext.xml作用相同
       @Configuration也会被注册到Spring容器中，因为它本身也是一个@Component

    @ComponentScan("com.etjava.model")// 扫描包 将包下的所有类注册到spring容器中

    @Component
    public @interface Configuration{}
 */
@Configuration
@ComponentScan("com.etjava.model")// 扫描包 将包下的所有类注册到spring容器中
@Import(AppConfig2.class) // 引入其他配置类 相当于spring的xml中的<import resource="beans.xml"/>
public class AppConfig {

    /*
    @Bean 注册一个bean,相当于 <bean id="user" class="xxx">
        这个方法的名字相当于bean标签的id
        这个方法的返回值 相当于bean的class属性
     */
    @Bean
    public User user(){
        System.out.println("AppConfig......");
        return new User();// 相当于需要注入到Spring中的对象
    }
}
