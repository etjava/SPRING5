package com.etjava.test;

import com.etjava.model.User;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
    public static void main(String[] args) {
        // 创建Spring上下文对象
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        // 获取Spring中配置好的User对象
        User user = (User)context.getBean("user");
        User user2 = (User)context.getBean("ddddd");// 通过别名方式获取user对象
        // 调用user对象中的show方法
        user.show();
        System.out.println(user == user2);
    }
}
