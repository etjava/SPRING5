package com.etjava.model;

public class User {
    private String userName;

    public User(int age){
        System.out.println("User类的无参构造方法");
    }
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void show(){
        System.out.println("name  = "+userName);
    }
}
