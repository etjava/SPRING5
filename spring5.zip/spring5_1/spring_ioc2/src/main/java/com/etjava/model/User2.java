package com.etjava.model;

public class User2 {
    private String userName;


    public User2(){
        System.out.println("User2类的无参构造方法");
    }
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void show(){
        System.out.println("name  = "+userName);
    }
}
