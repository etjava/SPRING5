package com.etjava.model;

// 客户 - 租房的人
public class Test {
    public static void main(String[] args) {
        // 直接找到房主去租房子
//        Host host = new Host();
//        host.rent();

        // 直接找不到房主 可以找中介 通过中介去租房子 - 这就是代理模式
        // 房主要出租房子 感觉太繁琐直接交给中介去处理
        Host host = new Host();
        // 代理 中介带你去找房子 但是代理角色一般会有一些附属操作
        Proxy proxy = new Proxy(host);
        // 不用面对房主 直接找中介即可
        proxy.rent();

    }
}
