package com.etjava.model;

// 真实角色 - （房主）租房
public class Host implements Rent{
    @Override
    public void rent() {
        System.out.println("房主要出租房子");
    }
}
