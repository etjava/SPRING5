package com.etjava.model;

// 租房
public interface Rent {

    public void rent();
}
