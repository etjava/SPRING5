package com.etjava.model;

// 中介 - 代理
public class Proxy implements Rent{
    private Host host;

    public Proxy() {
    }

    public Proxy(Host host) {
        this.host = host;
    }

    // 帮助房主出租房子 代理后会有额外附属操作
    @Override
    public void rent() {
        // 中介的附属操作
        System.out.println("中介带你看房");
        System.out.println("中介收取费用");
        System.out.println("中介签租赁合同");
        // 租房的核心方法
        host.rent();
    }
}
