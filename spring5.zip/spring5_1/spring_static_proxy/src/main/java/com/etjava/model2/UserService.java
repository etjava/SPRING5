package com.etjava.model2;

// 抽象角色 - 用户信息的增删改查
public interface UserService {
    public void add();
    public void delete();
    public void update();
    public void query();
}
