package com.etjava.model2;

public class Test {
    public static void main(String[] args) {
        UserService userService = new UserServiceImpl();
        //userService.add();// 如果需要在调用方法前添加日志记录 这种方式涉及到修改原业务 不推荐

        UserServiceProxy proxy = new UserServiceProxy(userService);
        proxy.add();
        proxy.query();
    }
}
