package com.etjava.dao.impl;

import com.etjava.dao.UserDao;

public class UserOrderDaoImpl implements UserDao {
    @Override
    public void findUser() {
        System.out.println("获取用户订单数据的方法");
    }
}
