package com.etjava.dao;

public interface UserDao {
    void findUser();
}
