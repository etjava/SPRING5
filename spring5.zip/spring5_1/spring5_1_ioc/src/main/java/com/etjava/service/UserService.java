package com.etjava.service;

public interface UserService {
    void findUser();
}
