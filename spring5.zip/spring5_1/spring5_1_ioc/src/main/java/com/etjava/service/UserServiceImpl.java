package com.etjava.service;

import com.etjava.dao.UserDao;
import com.etjava.dao.impl.UserDaoImpl;

public class UserServiceImpl implements UserService{

    private UserDao userDao;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public void findUser() {
        System.out.println("处理获取用户数据的方法");
        userDao.findUser();
    }
}
