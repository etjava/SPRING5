package com.etjava.dao.impl;

import com.etjava.dao.UserDao;

public class UserDaoImpl implements UserDao {
    @Override
    public void findUser() {
        System.out.println("默认获取用户数据的方法");
    }
}
