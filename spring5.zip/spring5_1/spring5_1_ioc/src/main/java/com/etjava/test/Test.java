package com.etjava.test;

import com.etjava.dao.impl.UserDaoImpl;
import com.etjava.dao.impl.UserOrderDaoImpl;
import com.etjava.service.UserService;
import com.etjava.service.UserServiceImpl;

public class Test {
    public static void main(String[] args) {
        UserServiceImpl userService = new UserServiceImpl();
        userService.setUserDao(new UserOrderDaoImpl());
        userService.findUser();
    }
}
