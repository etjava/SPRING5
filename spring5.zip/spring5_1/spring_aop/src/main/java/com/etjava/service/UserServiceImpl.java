package com.etjava.service;

public class UserServiceImpl implements UserSerice{
    @Override
    public void add() {
        System.out.println("添加用户信息");
    }

    @Override
    public void delete() {
        System.out.println("删除用户信息");
    }

    @Override
    public void modify() {
        System.out.println("修改用户信息");
    }

    @Override
    public void query() {
        System.out.println("查询用户信息");
    }
}
