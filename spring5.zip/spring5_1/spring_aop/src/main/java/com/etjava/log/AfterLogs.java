package com.etjava.log;


import org.springframework.aop.AfterReturningAdvice;

import java.lang.reflect.Method;

// 后置通知
public class AfterLogs implements AfterReturningAdvice {

    /*
    参数解释
        returnValue 返回值
        method 要执行的方法
        args 执行方法时可能需要的参数
        target 目标对象 - 要被执行的对象
     */
    @Override
    public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable {
        System.out.println("执行了"+method.getName()+"方法 其返回结果为"+returnValue);
    }
}
