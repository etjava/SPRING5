package com.etjava;

import com.etjava.service.UserSerice;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        UserSerice userService = context.getBean("userService", UserSerice.class);
        userService.add();
        userService.delete();
        userService.modify();
        userService.query();
    }
}
