package com.etjava;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

// 注解方式实现AOP
@Aspect // 标注这是一个切面
public class AnnocationPointCut {

    // 定义切点和通知
    // 方法执行前切入
    @Before("execution(* com.etjava.service.UserServiceImpl.*(..))")
    public void before1(){
        System.out.println("方法执行前------------");
    }
    // 后置通知
    @After("execution(* com.etjava.service.UserServiceImpl.*(..))")
    public void after1(){
        System.out.println("方法执行后------------");
    }

    // 环绕通知
    @Around("execution(* com.etjava.service.UserServiceImpl.*(..))")
    public void around(ProceedingJoinPoint joinPoint) throws Throwable {
        System.out.println("环绕前");
        // 执行方法 - 要给哪个方法进行切入的方法
        Object proceed = joinPoint.proceed();
        System.out.println("环绕后");
        // 获取签名-执行的是哪个方法
        Signature signature = joinPoint.getSignature();
        System.out.println(signature);
    }
}
