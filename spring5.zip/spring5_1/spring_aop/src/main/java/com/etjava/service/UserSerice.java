package com.etjava.service;

public interface UserSerice {
    public void add();
    public void delete();
    public void modify();
    public void query();
}
