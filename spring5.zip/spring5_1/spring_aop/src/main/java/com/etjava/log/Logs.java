package com.etjava.log;

import org.springframework.aop.MethodBeforeAdvice;

import java.lang.reflect.Method;

// 前置通知
public class Logs implements MethodBeforeAdvice {
    @Override
    /*
    参数解释
        method 要执行的方法
        args 执行方法时可能需要的参数
        target 目标对象 - 要被执行的对象
     */
    public void before(Method method, Object[] args, Object target) throws Throwable {
        System.out.println(target.getClass().getName()+"的"+method.getName()+"方法 被执行了");
    }
}
