package com.etjava.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
    private Integer id;
    private String stuName;
    private Integer age;

    public User(String stuName, Integer age) {
        this.stuName = stuName;
        this.age = age;
    }
}
