package com.etjava.mapper.impl;

import com.etjava.mapper.UserMapper;
import com.etjava.model.User;
import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import java.util.List;

public class UserMapperImpl extends SqlSessionDaoSupport implements UserMapper {


    @Override
    public List<User> list() {
        SqlSession sqlSession = getSqlSession();
        UserMapper u = sqlSession.getMapper(UserMapper.class);
        return u.list();
    }

    @Override
    public void add(User user) {
        SqlSession sqlSession = getSqlSession();
        UserMapper u = sqlSession.getMapper(UserMapper.class);
        u.add(user);
    }

    @Override
    public int remove(int id) {
        SqlSession sqlSession = getSqlSession();
        UserMapper u = sqlSession.getMapper(UserMapper.class);
        return u.remove(id);
    }

    // 测试事务 该方法内的要么都成功要么都失败
    public void acid(){
        add(new User("999",22));
        int i=1/0;
        remove(100);
    }
}
