package com.etjava;

import com.etjava.mapper.UserMapper;
import com.etjava.mapper.impl.UserMapperImpl;
import com.etjava.model.User;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class Test {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        UserMapper mapper = context.getBean("userMapper", UserMapper.class);
        List<User> list = mapper.list();
        for (User user : list) {
            System.out.println(user);
        }
    }
}
