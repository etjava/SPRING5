package com.etjava.mapper;

import com.etjava.model.User;

import java.util.List;

public interface UserMapper {
    List<User> list();

    // 添加一个用户
    void add(User user);
    // 删除一个用户
    int remove(int id);

    void acid();

}
